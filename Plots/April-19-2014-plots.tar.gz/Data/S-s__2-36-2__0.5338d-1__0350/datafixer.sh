#!/bin/bash
cat overlap.out | python ./data_parser.py > intermediate_fixed.out
